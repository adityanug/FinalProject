<?php

namespace App\Controllers;

use App\Models\BukuModel;

class buku extends BaseController
{
    protected $buku;

    function __construct()
    {

        $this->buku = new BukuModel();
        $this->pager = \Config\Services::pager();
    }

    public function index() 
    {
    $currentPage = $this->request->getVar('page_buku') ? $this->request->getVar('page_buku') : 1;
    $data=[
      'pageTitle' => 'Data Buku',
      'buku'  => $this->buku->paginate(3, 'buku'),
      'pager'  => $this->buku->pager,
      'currentPage' => $currentPage
      
    ];
        return view('dashboard/buku', $data);
    }
    public function create()
    {
    $data['pageTitle'] = 'Input Data Buku';
    return view('dashboard/buku_create', $data);
    }
    
    public function store()
    {
    if (!$this->validate([
    'id_buku' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'judul' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'pengarang' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    
    'penerbit' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'tahun' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'foto' => [
    'rules' => 'uploaded[foto]|mime_in[foto,image/jpg,image/jpeg,image/gif,image/png]|max_size[foto,1024]',
    'errors' => [
    'uploaded' => 'Harus Ada File yang diupload',
    'mime_in' => 'File Extention Harus Berupa jpg,jpeg,gif,png',
    'max_size' => 'Ukuran File Maksimal 1 MB'
    ]
    ],
   
    ])) {
    session()->setFlashdata('error', $this->validator->listErrors());
    return redirect()->back()->withInput();
    }
    $filefoto = $this->request->getFile('foto');
    $namaFilefoto = $filefoto->getRandomName();
    $filefoto->move('img', $namaFilefoto);
    
    $this->buku->insert([
    'id_buku' => $this->request->getVar('id_buku'),
    'judul' => $this->request->getVar('judul'),
    'pengarang' => $this->request->getVar('pengarang'),
    'penerbit' => $this->request->getVar('penerbit'),
    'tahun' => $this->request->getVar('tahun'),
    'foto'  =>$namaFilefoto

    
    ]);
    session()->setFlashdata('message', 'Tambah Data Buku
    Berhasil');
    return redirect()->to('/buku');
    }
    
    function edit($id_buku)
    {
    $dataBuku = $this->buku->find($id_buku);
    if (empty($dataBuku)) {
    throw new
    \CodeIgniter\Exceptions\PageNotFoundException('Data Buku
    Tidak ditemukan !');
    }
    $data['pageTitle'] = 'Edit Data Buku';
    $data['buku'] = $dataBuku;
    return view('dashboard/buku_edit', $data);
    }
    public function update($id_buku)
    {
    if (!$this->validate([
    'judul' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'pengarang' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    
    'penerbit' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'tahun' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'foto' => [
    'rules' => 'uploaded[foto]|mime_in[foto,image/jpg,image/jpeg,image/gif,image/png]|max_size[foto,1024]',
    'errors' => [
    'uploaded' => 'Harus Ada File yang diupload',
    'mime_in' => 'File Extention Harus Berupa jpg,jpeg,gif,png',
    'max_size' => 'Ukuran File Maksimal 1 MB'
    ]
    ],
                           
])) {
session()->setFlashdata('error', $this->validator->listErrors());
return redirect()->back();
}
                        
$filefoto = $this->request->getFile('foto');
$namaFilefoto = $filefoto->getRandomName();
$filefoto->move('img', $namaFilefoto);

$this->buku->update($id_buku, [
'judul' => $this->request->getVar('judul'),
'pengarang' => $this->request->getVar('pengarang'),
'penerbit' => $this->request->getVar('penerbit'),
'tahun' => $this->request->getVar('tahun'),
'foto'  =>$namaFilefoto
                           
]);
session()->setFlashdata('message', 'Update Data Buku Berhasil');
return redirect()->to('/buku'); 
}
               
 function delete($id_buku)
{
$dataBuku = $this->buku->find($id_buku);
if (empty($dataBuku)) {
throw new
\CodeIgniter\Exceptions\PageNotFoundException('Data Buku Tidak ditemukan !');
}
$this->buku->delete($id_buku);
session()->setFlashdata('message', 'Delete Data Buku Berhasil');
return redirect()->to('/buku');
}
    
                             
public function view($id_buku)
  {
$dataBuku = $this->buku->find($id_buku);
if (empty($dataBuku)) {
throw new 
\CodeIgniter\Exceptions\PageNotFoundException('Data Buku Tidak ditemukan !');
}
$data['pageTitle'] = 'Data Buku';
$data['buku'] = $dataBuku;
return view('dashboard/buku_view', $data);
}
                                           
}
    