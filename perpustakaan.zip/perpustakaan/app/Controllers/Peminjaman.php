<?php

namespace App\Controllers;

use App\Models\PeminjamanModel;

class peminjaman extends BaseController
{
    protected $peminjaman;

    function __construct()
    {
        $this->peminjaman = new PeminjamanModel();

    }

    public function index() 
    {
        $data['pageTitle'] = 'Peminjaman dan Pengembalian';
        $data['peminjaman'] = $this->peminjaman->findAll();
        return view('dashboard/peminjaman', $data);
    }
    public function create()
    {
    $data['pageTitle'] = 'Input Data Peminjaman';
    return view('dashboard/peminjaman_create', $data);
    }
    
    public function store()
    {
    if (!$this->validate([
    'id_pinjaman' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'nama_peminjam' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'nama_buku' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    
    'tanggal' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'kembali' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
 
    ])) {
    session()->setFlashdata('error', $this->validator->listErrors());
    return redirect()->back()->withInput();
    }
    
    $this->peminjaman->insert([
    'id_pinjaman' => $this->request->getVar('id_pinjaman'),
    'nama_peminjam' => $this->request->getVar('nama_peminjam'),
    'nama_buku' => $this->request->getVar('nama_buku'),
    'tanggal' => $this->request->getVar('tanggal'),
    'kembali' => $this->request->getVar('kembali')


    
    ]);
    session()->setFlashdata('message', 'Tambah Data Peminjaman
    Berhasil');
    return redirect()->to('/peminjaman');
    }
    
    function edit($id_pinjaman)
        {
            $dataPeminjaman = $this->peminjaman->find($id_pinjaman);
            if (empty($dataPeminjaman)) {
                throw new
    \CodeIgniter\Exceptions\PageNotFoundException('Data Peminjaman
    Tidak ditemukan !');
            }
            $data['pageTitle'] = 'Edit Data Peminjaman';
            $data['peminjaman'] = $dataPeminjaman;
            return view('dashboard/peminjaman_edit', $data);
                   }
                   public function update($id_pinjaman)
                   {
                       if (!$this->validate([
                            'nama_peminjam' => [
                            'rules' => 'required',
                            'errors' => [
                            'required' => '{field} Harus diisi'
                            ]
                            ],
                            'nama_buku' => [
                            'rules' => 'required',
                            'errors' => [
                            'required' => '{field} Harus diisi'
                            ]
                            ],
                            
                            'tanggal' => [
                            'rules' => 'required',
                            'errors' => [
                            'required' => '{field} Harus diisi'
                            ]
                            ],
                            'kembali' => [
                            'rules' => 'required',
                            'errors' => [
                            'required' => '{field} Harus diisi'
                            ]
                            ],
                           
                       ])) {
                           session()->setFlashdata('error', $this->validator->listErrors());
                           return redirect()->back();
                       }
                        

                       $this->peminjaman->update($id_pinjaman, [
                        'id_peminjam' => $this->request->getVar('id_peminjam'),
                        'nama_peminjam' => $this->request->getVar('nama_peminjam'),
                        'nama_buku' => $this->request->getVar('nama_buku'),
                        'tanggal' => $this->request->getVar('tanggal'),
                        'kembali' => $this->request->getVar('kembali')
                           
                       ]);
                       session()->setFlashdata('message', 'Update Data Peminjaman
               Berhasil');
                       return redirect()->to('/peminjaman'); 
                                 }
               
                                 function delete($id_pinjaman)
                                 {
                                     $dataPeminjaman = $this->peminjaman->find($id_pinjaman);
                                     if (empty($dataPeminjaman)) {
                                         throw new
                             \CodeIgniter\Exceptions\PageNotFoundException('Data Peminjaman
                             Tidak ditemukan !');
                                     }
                                     $this->peminjaman->delete($id_pinjaman);
                                     session()->setFlashdata('message', 'Buku Telah diKembalikan');
                                     return redirect()->to('/peminjaman');
                             }
    
                                           
               }
    