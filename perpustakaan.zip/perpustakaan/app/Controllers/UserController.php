<?php

namespace App\Controllers;

class UserController extends BaseController
{
    public function index()
    {
        $data['pageTitle'] = 'Home';
        return view('dashboard/home', $data);
    }
    public function profile()
    {
        $data['pageTitle'] = 'Profile';
        return view('dashboard/profile', $data);
    }
    
    public function Mahasiswa()
    {
        $data['pageTitle'] = 'Mahasiswa';
        return view('dashboard/Mahasiswa', $data);
    }
    public function buku()
    {
        $data['pageTitle'] = 'buku';
        return view('dashboard/buku', $data);
    }
    public function peminjaman()
    {
        $data['pageTitle'] = 'peminjaman';
        return view('dashboard/peminjaman', $data);
    }
}
