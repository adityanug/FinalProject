<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;

class UsersSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                "username"          => "Rama",
                "password"          =>  password_hash("n0vta", PASSWORD_BCRYPT),
                "name"              => "Rasyid Novta",
                "created_at"        => Time::now()
            ]
        ];
        $this->db->table('users')->insertBatch($data);

    }
}
