<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<div class="col-md-10">
<!-- general form elements -->
<div class="card card-primary">
<div class="card-header">
<h3 class="card-title">Tambah Data Peminjaman</h3>
</div>

<!-- /.card-header -->
<!-- form start -->
<?php if (!empty(session()->getFlashdata('error'))) : ?>
<div class="alert alert-light alert-dismissible fade show" role="alert">
<h4 class="alert-heading">Periksa Entrian Form</h4>
</hr />
<?php echo session()->getFlashdata('error'); ?>
<button type="button" class="close" data-dismiss="alert" aria- label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>

<form class="form-horizontal" method="post" action="<?=base_url('peminjaman/store')?>" enctype="multipart/form-data">
<?= csrf_field(); ?>
<div class="card-body">
<div class="form-group row">
<label for="id_pinjaman" class="col-sm-2 col-form- label">ID Pinjaman</label>
<div class="col-sm-6">
<input type="text" class="form-control" id="id_pinjaman" name="id_pinjaman" placeholder="ID Pinjaman" value="<?= old('id_pinjaman'); ?>">
</div>
</div>

<div class="form-group row">
<label for="judul" class="col-sm-2 col-form- label">Nama Peminjam</label>
<div class="col-sm-6">
<input type="text" class="form-control" id="nama_peminjam" name="nama_peminjam" value="<?= old('nama_peminjam'); ?>">
</div>
</div>

<div class="form-group row">
<label for="jenis_kelamin" class="col-sm-2 col-form- label">Nama Buku</label>
<div class="col-sm-6">
<select name="nama_buku" class="form-control" id="nama_buku">
<option value=""> Pilih Buku </option>    
<option value="Novel Perahu Kertas">Novel Perahu Kertas</option>
<option value="Mystery Woman">Mystery Woman</option>
<option value="Jingga dan Senja">Jingga dan Senja</option>
<option value="Pelakor">Pelakor</option>
<option value="Gustira">Gustira</option>
<option value="Sebatas Mimpi">Sebatas Mimpi</option>
<option value="Sang Pemimpi">Sang Pemimpi</option>
<option value="Struktur Data">Struktur Data</option>
<option value="Belajar Coding Itu Penting">Belajar Coding Itu Penting</option>
<option value="Pemroograman Web Dasar">Pemroograman Web Dasar</option>
<option value="Panduan HTML Untuk Pemula">Panduan HTML Untuk Pemula</option>
<option value="Buku Sakti Pemrograman">Buku Sakti Pemrograman</option>
</select>
</div>
</div>

<div class="form-group row">
<label for="tanggal" class="col-sm-2 col-form- label">Tanggal</label>
<div class="col-sm-6">
<input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= old('tanggal'); ?>">
</div>
</div>

<div class="form-group row">
<label for="tanggal" class="col-sm-2 col-form- label">Tanggal Kembali</label>
<div class="col-sm-6">
<input type="date" class="form-control" id="kembali" name="kembali" value="<?= old('kembali'); ?>">
</div>
</div>


</div>
<!-- /.card-body -->
<div class="card-footer">
<button type="submit" class="btn btn-primary btn-block">Simpan</button>

</div>
<!-- /.card-footer -->
</form> 

</div>
<!-- /.card -->
</div>
<?= $this->endSection('content'); ?>