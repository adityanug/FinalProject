<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<!-- /.card-header -->
<div class="card-body">

<?php if (!empty(session()->getFlashdata('message'))) : ?>
<div class="alert alert-success alert-dismissible fade show"role="alert">
<?php echo session()->getFlashdata('message'); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">

<span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>
<a href="<?= base_url('/peminjaman/create'); ?>" class="btn btn-primary">Tambah</a>
<hr />
<table class="table table-bordered">
<thead>
<tr>
<th>No</th>
<th>ID Peminjaman</th>
<th>Nama Peminjam</th>
<th>Nama Buku</th>
<th>Tanggal Pinjam</th>
<th>Tanggal Kembali</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php
$no = 1;
foreach ($peminjaman as $row)
{
?>
<tr>
<td><?= $no++; ?></td>
<td><?= $row->id_pinjaman; ?></td>
<td><?= $row->nama_peminjam; ?></td>
<td><?= $row->nama_buku; ?></td>
<td><?= $row->tanggal; ?></td>
<td><?= $row->kembali; ?></td>
<td>

<a title="Edit" href="<?= base_url("peminjaman/edit/$row->id_pinjaman"); ?>" class="btn btn-info">Edit</a>
<a title="Di Kembalikan" href="<?=base_url("peminjaman/delete/$row->id_pinjaman") ?>" class="btn btn-success"onclick="return confirm('Buku Telah dikembalikan')">Di Kembalikan</a>
</td>

</tr>
<?php
}
?>
</tbody>
</table>
</div>
<!-- /.card-body -->
<?= $this->endSection('content'); ?>