<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<div class="col-md-10">
<!-- general form elements -->
<div class="card card-primary">
<div class="card-header">
<h3 class="card-title">Edit Data buku</h3>
</div>

<!-- /.card-header -->
<!-- form start -->
<?php if (!empty(session()->getFlashdata('error'))) : ?>
<div class="alert alert-light alert-dismissible fade show" role="alert">
<h4 class="alert-heading">Periksa Entrian Form</h4>
</hr />
<?php echo session()->getFlashdata('error'); ?>
<button type="button" class="close" data-dismiss="alert" aria- label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>

<form class="form-horizontal" method="post" action="<?=base_url('peminjaman/update/' . $peminjaman->id_pinjaman) ?>"enctype="multipart/form-data">
<?= csrf_field(); ?>
<div class="card-body">



<div class="form-group row">
<label for="nama" class="col-sm-2 col-form- label">Nama Peminjam</label>
<div class="col-sm-6">
<input type="text" class="form-control" id="nama_peminjam" name="nama_peminjam" value="<?= $peminjaman->nama_peminjam; ?>">
</div>
</div>

<div class="form-group row">
<label for="jurusan" class="col-sm-2 col-form- label">Nama Buku</label>
<div class="col-sm-6">
<select name="nama_buku" class="form-control" id="nama_buku">
<option value="Novel Perahu Kertas"<?= ($peminjaman->nama_buku=="Novel Perahu Kertas"? "selected" : ""); ?>>Novel Perahu Kertas</option>
<option value="Mystery Woman"<?= ($peminjaman->nama_buku=="Mystery Woman"? "selected" : ""); ?>>Mystery Woman</option>
<option value="Jingga dan Senja"<?= ($peminjaman->nama_buku=="Jingga dan Senja"? "selected" : ""); ?>>Jingga dan Senja</option>
<option value="Pelakor"<?= ($peminjaman->nama_buku=="Pelakor"? "selected" : ""); ?>>Pelakor</option>
<option value="Gustira"<?= ($peminjaman->nama_buku=="Gustira"? "selected" : ""); ?>>Gustira</option>
<option value="Sebatas Mimpi"<?= ($peminjaman->nama_buku=="Sebatas Mimpi"? "selected" : ""); ?>>Sebatas Mimpi</option>
<option value="Sang Pemimpi"<?= ($peminjaman->nama_buku=="Sang Pemimpi"? "selected" : ""); ?>>Sang Pemimpi</option>
<option value="Struktur Data"<?= ($peminjaman->nama_buku=="Struktur Data"? "selected" : ""); ?>>Struktur Data</option>
<option value="Belajar Coding Itu Penting"<?= ($peminjaman->nama_buku=="Belajar Coding Itu Penting"? "selected" : ""); ?>>Belajar Coding Itu Penting</option>
<option value="Pemroograman Web Dasar"<?= ($peminjaman->nama_buku=="Pemroograman Web Dasar"? "selected" : ""); ?>>Pemroograman Web Dasar</option>
<option value="Panduan HTML Untuk Pemula"<?= ($peminjaman->nama_buku=="Panduan HTML Untuk Pemula"? "selected" : ""); ?>>Panduan HTML Untuk Pemula</option>
<option value="Buku Sakti Pemrograman"<?= ($peminjaman->nama_buku=="Buku Sakti Pemrograman"? "selected" : ""); ?>>Buku Sakti Pemrograman</option>
</select>
</div>
</div>

<div class="form-group row">
<label for="jenis_kelamin" class="col-sm-2 col-form- label">Tanggal Peminjaman</label>
<div class="col-sm-6">
<input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $peminjaman->tanggal; ?>">
</div>
</div>

<div class="form-group row">
<label for="no_telp" class="col-sm-2 col-form-label">tanggal Kembali</label>
<div class="col-sm-6">
<input type="date" class="form-control" id="kembali"name="kembali" value="<?= $peminjaman->kembali; ?>" />
</div>
</div>




</div>
<!-- /.card-body -->
<div class="card-footer">
<button type="submit" class="btn btn-primary btn-block">Simpan</button>

</div>
<!-- /.card-footer -->
</form>

</div>
<!-- /.card -->
</div>
<?= $this->endSection('content'); ?>
