<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<div class="col-md-12">
<!-- general form elements -->
<section class="content">
<div class="container-fluid">
<div class="row">
<!-- /.card-header -->
<!-- form start -->
<div class="col-md-3">
<!-- Profile Image -->
<div class="card card-primary card-outline">
<div class="card-body box-profile">
<div class="text-center">
<img class="profile-user-img img-fluid img-square" src="/img/<?=$buku->foto; ?>" alt="User profile picture">
</div>
<h3 class="profile-username text-center"><?=$buku->judul; ?></h3>
<p class="text-muted text-center"><?= $buku->id_buku; ?></p>
</div>
<!-- /.card-body -->
</div>
<!-- /.card -->
</div>
<div class="col-md-9">
<div class="card card-primary">
<div class="card-header">
<h3 class="card-title">About Book</h3>
</div>
<!-- /.card-header -->
<div class="card-body">
<strong><i class="fas fa-book mr-1"></i> Judul</strong>
<p class="text-muted"> <?= $buku->judul; ?> 
</p>
<hr>
<strong><i class="fas fa-user -alt mr-1"></i> Pengarang</strong>
<p class="text-muted"><?= $buku->pengarang;
?></p>
<hr>
<strong><i class="fas fa-map-marker-alt mr-1"></i> Penerbit</strong>
<p class="text-muted"><?= $buku->penerbit; ?></p>
<hr>
<strong><i class="far fa-calendar-alt mr-1"></i> Tahun</strong>
<p class="text-muted"><?= $buku->tahun;
?></p>

</div>
<!-- /.card-body -->
</div>
<!-- /.card -->
</div>
</div>
<!-- /.card -->
</div>
</div>
<?= $this->endSection('content'); ?>
